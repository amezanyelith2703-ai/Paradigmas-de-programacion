// Daniela Anyelith Amezquita Argote
// 2026670244

package org.example;

import org.example.ipn.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE FIGURAS GEOMÉTRICAS ===\n");

        List<FigurasGeometricas> figuras = new ArrayList<>();

        figuras.add(new Circulo(5.0));
        figuras.add(new Rectangulo(4.0, 6.0));
        figuras.add(new Triangulo(3.0, 4.0, 5.0));

        for (FigurasGeometricas figura : figuras) {
            figura.mostrarInformacion();
        }
    }
}

// https://github.com/amezanyelith2703-ai/Paradigmas-de-programacion/upload/main




