package org.example.ipn;

public class Triangulo extends FigurasGeometricas {
    private double lado1;
    private double lado2;
    private double lado3;

    public Triangulo(double lado1, double lado2, double lado3) {
        validarLados(lado1, lado2, lado3);
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }

    private void validarLados(double a, double b, double c) {
        if (a <= 0 || b <= 0 || c <= 0) {
            throw new IllegalArgumentException("Los lados deben ser mayores a cero.");
        }
        // Validación de Desigualdad Triangular
        if ((a + b <= c) || (a + c <= b) || (b + c <= a)) {
            throw new IllegalArgumentException("Los lados proporcionados no forman un triángulo válido.");
        }
    }

    public double getLado1() {
        return lado1; }
    public double getLado2() {
        return lado2; }
    public double getLado3() {
        return lado3; }

    @Override
    public double calcularArea() {
        // Fórmula de Herón
        double s = calcularPerimetro() / 2.0;
        return Math.sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
    }

    @Override
    public double calcularPerimetro() {
        return lado1 + lado2 + lado3;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Figura: Triángulo");
        System.out.printf("Lado 1: %.1f%n", lado1);
        System.out.printf("Lado 2: %.1f%n", lado2);
        System.out.printf("Lado 3: %.1f%n", lado3);
        System.out.printf("Área: %.2f%n", calcularArea());
        System.out.printf("Perímetro: %.2f%n%n", calcularPerimetro());
    }
}