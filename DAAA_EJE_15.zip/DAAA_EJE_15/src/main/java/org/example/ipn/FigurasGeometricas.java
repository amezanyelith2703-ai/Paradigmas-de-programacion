package org.example.ipn;

public abstract class FigurasGeometricas {

    // Métodos abstractos sin cuerpo
    public abstract double calcularArea();
    public abstract double calcularPerimetro();
    public abstract void mostrarInformacion();
}
