package org.example.figuras;

public class Circulo
{
    private double x;
    private double y;
    private double r;


    public Circulo()
    {
        this.x=0;
        this.y=0;
        this.r=1;
    }

    public Circulo(double x)
    {
        this.x=x;
        this.y=0;
        this.r=1;

    }

    public Circulo(double x, double y)
    {
        this.x=x;
        this.y=y;
        this.r=1;
    }

    public Circulo(double x,double y, double r)
    {
        this.x=x;
        this.y=y;
        this.r=r;
    }

    public double CalcularArea()
    {
        return Math.PI * this.r * this.r;
    }

    public double CalcularPerimetro()
    {
        return 2 * Math.PI * this.r;
    }

    public void moverx(double unidadesx)
    {
        this.x=this.x+unidadesx;
    }

    public void movery(double unidadesy)
    {
        this.y=this.y+unidadesy;
    }

    public void moverxy(double unidadesx, double unidadesy)
    {
        this.x=this.x+unidadesx;
        this.y=this.y+unidadesy;
    }

    public void dibujar()
    {
        System.out.println("me dibuja en la posicion x:"+this.x + " y: "+this.y+ " r: "+this.r);
    }
}