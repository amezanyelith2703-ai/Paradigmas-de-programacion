package org.example;

import org.example.figuras.Circulo;

public class Main {
    public static void main(String[] args) {

        // 1. Crear al menos tres instancias de la clase Circulo
        Circulo circulo1 = new Circulo();
        Circulo circulo2 = new Circulo(3.0, 4.0);
        Circulo circulo3 = new Circulo(1.0, 2.0, 5.0);

        // 2. Mostrar estado inicial de cada círculo
        System.out.println("---- ESTADO INICIAL DE LOS CÍRCULOS -----");
        circulo1.dibujar();
        circulo2.dibujar();
        circulo3.dibujar();

        // 3. Calcular y mostrar Área y Perímetro
        System.out.println("\n---- CÁLCULOS DE ÁREA Y PERÍMETRO -----");
        System.out.println("Círculo 1 -> Área: " + circulo1.CalcularArea() + " | Perímetro: " + circulo1.CalcularPerimetro());
        System.out.println("Círculo 2 -> Área: " + circulo2.CalcularArea() + " | Perímetro: " + circulo2.CalcularPerimetro());
        System.out.println("Círculo 3 -> Área: " + circulo3.CalcularArea() + " | Perímetro: " + circulo3.CalcularPerimetro());

        // 4. Probar los métodos de movimiento
        System.out.println("\n---- MOVIENDO CÍRCULOS ----");
        circulo1.moverx(5.0);       // Mover en x
        circulo2.movery(-2.0);      // Mover en y
        circulo3.moverxy(3.0, 4.0);  // Mover en x e y

        // 5. Dibujar de nuevo para comprobar las nuevas posiciones
        System.out.println("\n---- POSICIONES DESPUÉS DEL MOVIMIENTO -----");
        circulo1.dibujar();
        circulo2.dibujar();
        circulo3.dibujar();
    }
}