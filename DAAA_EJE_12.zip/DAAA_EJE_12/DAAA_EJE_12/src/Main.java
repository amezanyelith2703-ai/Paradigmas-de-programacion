package org.upiiz;

public class Main {
    public static void main(String[] args) {

        Lienzo miLienzo = new Lienzo("Blanco", 800, 600);

        Linea linea = new Linea(20, 40, "Rojo", 1, false, 30, 60);

        Circulo circulo = new Circulo(30, 45, "Verde", 2, true, 5.0);

        miLienzo.agregarFigura(linea);
        miLienzo.agregarFigura(circulo);

        miLienzo.dibujarLienzo();
    }
}