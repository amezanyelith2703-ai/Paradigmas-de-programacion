package org.upiiz;

public abstract class  Figura {
    protected int x1;
    protected int y1;
    protected String color;
    protected int anchoLinea;
    protected boolean relleno;

    public Figura(int x1, int y1, String color, int anchoLinea, boolean relleno) {
        this.x1 = x1;
        this.y1 = y1;
        this.color = color;
        this.anchoLinea = anchoLinea;
        this.relleno = relleno;
    }
    public abstract void dibujar();
}
