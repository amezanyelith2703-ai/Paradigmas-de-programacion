package org.upiiz;

import java.util.ArrayList;
import java.util.List;

public class Lienzo {
    private List<Figura> figuras;
    private String colorFondo;
    private int ancho;
    private int alto;

    public Lienzo(String colorFondo, int ancho, int alto) {
        this.colorFondo = colorFondo;
        this.ancho = ancho;
        this.alto = alto;
        this.figuras = new ArrayList<>();
    }

    public void agregarFigura(Figura f) {
        this.figuras.add(f);
    }
    public void dibujarLienzo(){
        System.out.println("Lienzo");
        System.out.println("Color de Fondo: "+this.colorFondo);
        System.out.println("Dimensiones: " + this.ancho + "x" + this.alto);
        System.out.println("Figuras en el lienzo:");

        for (Figura f: figuras){
            f.dibujar();
        }
    }
}
