package org.upiiz;

public class Circulo extends Figura {
    private Double radio;

    public Circulo(int x1, int y1, String color, int anchoLinea, boolean relleno, Double radio) {
        super(x1, y1, color, anchoLinea, relleno);
        this.radio = radio;
    }

    @Override
    public void dibujar() {
        System.out.println("Tipo: Circulo");
        System.out.println("Coordenadas: (" + this.x1 + ", " + this.y1 + ")");
        System.out.println("Radio: "+this.radio);
        System.out.println("Color: "+this.color);
        System.out.println("Ancho de linea: "+this.anchoLinea);
        System.out.println("Relleno: "+this.relleno);
    }
}

