package org.upiiz;

public class Linea extends Figura {

    private int x2;
    private int y2;

    public Linea(int x1, int y1, String color, int anchoLinea, boolean relleno, int x2, int y2) {
        super(x1, y1, color, anchoLinea, relleno);
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public void dibujar() {
        System.out.println("Tipo: Linea");
        System.out.println("Coordenadas iniciales: (" + this.x1 + "," + this.y1 + ")");
        System.out.println("Coordenadas Finales: (" + this.x2 + "," + this.y2 + ")");
        System.out.println("Color: "+this.color);
        System.out.println("Ancho de linea: "+this.anchoLinea);
        System.out.println("Relleno: "+this.relleno);
    }
}
