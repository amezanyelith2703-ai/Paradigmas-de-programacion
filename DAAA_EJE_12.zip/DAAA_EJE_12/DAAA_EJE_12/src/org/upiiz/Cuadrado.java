package org.upiiz;

public class Cuadrado extends Figura {
    private int lado;

    public Cuadrado(int x1, int y1, String color, int anchoLinea, boolean relleno, int lado) {
        super(x1, y1, color, anchoLinea, relleno);
        this.lado = lado;
    }

    @Override
    public void dibujar() {
        System.out.println("Tipo: Cuadrado");
        System.out.println("Coordenadas: (" + this.x1 + "," + this.y1 +")");
        System.out.println("Lado: "+this.lado);
        System.out.println("Color: "+this.color);
        System.out.println("Ancho de linea: "+this.anchoLinea);
        System.out.println("Relleno: "+this.relleno);
    }
}
