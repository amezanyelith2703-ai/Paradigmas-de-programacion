package org.upiiz;

import java.util.List;

public class Poligono extends Figura{
    private List<Figura> puntos;

    public Poligono(int x1, int y1, String color, int anchoLinea, boolean relleno, List<Figura> puntos) {
        super(x1, y1, color, anchoLinea, relleno);
        this.puntos = puntos;
    }

    @Override
    public void dibujar() {
        System.out.println("Tipo: Poligono");
        System.out.println("Coordenadas: (" + this.x1 +"," + this.y1 +")");
        System.out.println("Puntos: "+this.puntos);
        System.out.println("Color: "+this.color);
        System.out.println("Ancho linea "+this.anchoLinea);
        System.out.println("Relleno: "+this.relleno);
    }
}
