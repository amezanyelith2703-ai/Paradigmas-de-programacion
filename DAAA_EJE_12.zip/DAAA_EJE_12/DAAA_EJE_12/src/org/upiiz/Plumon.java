package org.upiiz;

public class Plumon {
    private String color;
    private int anchoLinea;

    public Plumon(String color, int anchoLinea) {
        this.color = color;
        this.anchoLinea = anchoLinea;
    }
    public void mostrarInformacion() {
        System.out.println("Plumon Color: " + this.color + ", Ancho de línea: " + this.anchoLinea);
    }
}
