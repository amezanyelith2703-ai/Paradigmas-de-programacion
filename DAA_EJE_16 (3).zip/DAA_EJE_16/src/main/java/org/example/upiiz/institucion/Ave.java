package org.example.upiiz.institucion;

public class Ave {
    public void come(){
        System.out.println("Estoy comiendo pan");
    }

}
