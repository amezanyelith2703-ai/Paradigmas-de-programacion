package org.example.upiiz.institucion;

public class Persona {

    // Un unico metodo
    public void hablar(){
        System.out.println("Hola mundo");
    }
}
