package org.upiiz.institucion;

//Nota: Interfaces es una clase abstracta
//Y en general solo tiene metodos abstractos
//Por default son publicos y abstractos
public interface EnviadorMensajes {
    void enviarMensaje(String mensaje);
}
