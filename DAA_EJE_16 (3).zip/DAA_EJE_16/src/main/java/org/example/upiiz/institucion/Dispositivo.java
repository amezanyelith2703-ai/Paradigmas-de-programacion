package org.example.upiiz.institucion;

public class Dispositivo {

    public void encender(){
        System.out.println("Dispositivo encendido");

    }
}
