package org.example.upiiz.institucion;


import java.awt.*;
import java.util.ArrayList;

   public class InstitucionEducativa {
       // Atributos
       private String nombre;
       private List<EnviadorMensajes> mensajero;

       // constructor
       public InstitucionEducativa(String nombre) {
           this.nombre = nombre;
           mensajero = new ArrayList<>() {


               // Metodo para agregar mensajeros

               public void agregarMensajero(){
                

               }

           }

       }
   }
