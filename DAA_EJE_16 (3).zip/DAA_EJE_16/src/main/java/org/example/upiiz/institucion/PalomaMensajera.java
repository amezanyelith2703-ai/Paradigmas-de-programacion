package org.example.upiiz.institucion;

public class PalomaMensajera extends Ave implements EnviadorMensajes{

   //  Es hija de ave
    // Y aparte implementa el comportamiento de
    public void vuelaRapido{
        System.out.println("Estoy volando...");
    }
    @Override
    public void enviarMensaje()
}
