package models;

import java.util.ArrayList;
import java.util.List;

public class Laboratorio {
    private int id;
    private String nombre;
    private String color;
    private String encargado;
    private List<Mesa> mesas;

    // Constructor (según el diagrama)
    public Laboratorio(int id, String color, String nombre) {
        this.id = id;
        this.color = color;
        this.nombre = nombre;
        this.mesas = new ArrayList<>(); // Inicializamos la lista de mesas
    }

    // Métodos especificados en el diagrama
    public void agregarMesa(Mesa mesa) {
        this.mesas.add(mesa);
    }

    public void mostrarMesas() {
        System.out.println("Laboratorio: " + this.nombre + " [ID: " + this.id + ", Color: " + this.color + ", Encargado: " + this.encargado + "]");
        System.out.println("Mesas registradas:");

        for (Mesa mesa : mesas) {
            System.out.println("- Mesa de material: " + mesa.getClass().getName()); // O puedes imprimir detalles de la mesa si gustas
            mesa.mostrarComputadoras();
        }
    }

    // Getters y Setters adicionales por si los necesitas después
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getEncargado() {
        return encargado;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }
}

//https://github.com/amezanyelith2703-ai/Paradigmas-de-programacion/upload/main